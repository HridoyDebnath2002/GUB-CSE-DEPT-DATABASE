-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2024 at 09:49 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gub_cse_department`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrativestaff`
--

CREATE TABLE `administrativestaff` (
  `StaffID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Position` varchar(255) DEFAULT NULL,
  `DepartmentID` int(11) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `administrativestaff`
--

INSERT INTO `administrativestaff` (`StaffID`, `Name`, `Position`, `DepartmentID`, `Email`) VALUES
(101, 'MS. PARVIN KHATUN', 'Dept. Coordination Officer', 1, 'parvin@gmail.com'),
(102, 'MS. SURAIYA AKHTER', 'Jr. Dept. Co-ordination Officer', 1, 'suraiya@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `AlumniID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `GraduationYear` int(11) DEFAULT NULL,
  `CurrentEmployer` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`AlumniID`, `Name`, `GraduationYear`, `CurrentEmployer`, `Email`) VALUES
(1, 'Mohammad Rahman', 2022, 'ABC Ltd.', 'mohammad.rahman@gmail.com'),
(2, 'Sadia Ahmed', 2020, 'XYZ Corporation', 'sadia.ahmed@gmail.com'),
(3, 'Mehnaz Khan', 2019, 'PQR Solutions', 'mehnaz.khan@gmail.com'),
(4, 'Ahsan Ali', 2018, 'LMN Technologies', 'ahsan.ali@gmail.com'),
(5, 'Nadia Hassan', 2017, 'Green Energy Ltd.', 'nadia.hassan@gmail.com'),
(6, 'Fahim Ahmed', 2016, 'Tech Innovations', 'fahim.ahmed@gmail.com'),
(7, 'Sara Akter', 2015, 'Global Enterprises', 'sara.akter@gmail.com'),
(8, 'Kamal Khan', 2014, 'Smart Solutions', 'kamal.khan@gmail.com'),
(9, 'Farhana Islam', 2013, 'Bright Future Inc.', 'farhana.islam@gmail.com'),
(10, 'Rafiqul Haque', 2021, 'Data Experts', 'rafiqul.haque@gmail.com'),
(11, 'Nashra Begum', 2020, 'Digital Solutions', 'nashra.begum@gmail.com'),
(12, 'Imran Ahmed', 2019, 'Innovate IT', 'imran.ahmed@gmail.com'),
(13, 'Tasnim Khan', 2018, 'EcoTech Ltd.', 'tasnim.khan@gmail.com'),
(14, 'Sadia Chowdhury', 2017, 'Tech Innovations', 'sadia.chowdhury@gmail.com'),
(15, 'Aminul Islam', 2016, 'Global Enterprises', 'aminul.islam@gmail.com'),
(16, 'Rukhsana Begum', 2015, 'Data Solutions Inc.', 'rukhsana.begum@gmail.com'),
(17, 'Sohail Rahman', 2014, 'Bright Future Inc.', 'sohail.rahman@gmail.com'),
(18, 'Saima Akter', 2013, 'Smart Systems', 'saima.akter@gmail.com'),
(19, 'Rezaul Islam', 2022, 'Data Analytics', 'rezaul.islam@gmail.com'),
(20, 'Tariqul Haque', 2021, 'Tech Innovators', 'tariqul.haque@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `billhistory`
--

CREATE TABLE `billhistory` (
  `BillSerial` int(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `Amount` decimal(10,2) DEFAULT NULL,
  `BillType` varchar(255) DEFAULT NULL,
  `PaymentDate` date DEFAULT NULL,
  `DueDate` date DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billhistory`
--

INSERT INTO `billhistory` (`BillSerial`, `StudentID`, `Amount`, `BillType`, `PaymentDate`, `DueDate`, `Status`) VALUES
(1, 213002001, 9400.00, 'Tuition Fees', '2023-08-17', '2023-08-24', 'Paid'),
(2, 213002002, 8400.00, 'Tuition fee', '2023-08-17', '2023-08-24', 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `classrooms`
--

CREATE TABLE `classrooms` (
  `RoomID` int(11) NOT NULL,
  `Building` varchar(255) DEFAULT NULL,
  `Capacity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classrooms`
--

INSERT INTO `classrooms` (`RoomID`, `Building`, `Capacity`) VALUES
(111, 'D', 44),
(112, 'D', 41),
(113, 'D', 45),
(114, 'D', 40),
(115, 'K', 42),
(116, 'K', 44),
(117, 'K', 43),
(118, 'K', 45),
(119, 'L', 41),
(120, 'L', 45),
(121, 'L', 44),
(122, 'L', 42),
(123, 'J', 45),
(124, 'J', 43),
(125, 'J', 41),
(126, 'J', 44),
(131, 'F', 44),
(132, 'F', 42),
(133, 'F', 40),
(134, 'F', 43);

-- --------------------------------------------------------

--
-- Table structure for table `clubs`
--

CREATE TABLE `clubs` (
  `ClubID` varchar(20) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `PresidentStudentName` varchar(20) DEFAULT NULL,
  `ModaretorName` varchar(20) DEFAULT NULL,
  `Objective` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clubs`
--

INSERT INTO `clubs` (`ClubID`, `Name`, `PresidentStudentName`, `ModaretorName`, `Objective`) VALUES
('GUCC', 'Green University Computer Club ', 'Samin Ahmed', 'MR. MD. MONIRUL ISLA', 'Be developer to be leader');

-- --------------------------------------------------------

--
-- Table structure for table `courseevaluations`
--

CREATE TABLE `courseevaluations` (
  `EvaluationID` int(11) NOT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `FacultyID` int(11) DEFAULT NULL,
  `Semester` varchar(255) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `FeedbackText` text DEFAULT NULL,
  `Rating` double(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courseevaluations`
--

INSERT INTO `courseevaluations` (`EvaluationID`, `CourseID`, `StudentID`, `FacultyID`, `Semester`, `Year`, `FeedbackText`, `Rating`) VALUES
(1, 101, 213002001, 1, 'Fall', 2023, 'Perfect & helpfull', 4.80),
(2, 102, 213002002, 2, 'Fall', 2023, 'Students Friendly', 4.70);

-- --------------------------------------------------------

--
-- Table structure for table `coursematerials`
--

CREATE TABLE `coursematerials` (
  `MaterialID` int(11) NOT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coursematerials`
--

INSERT INTO `coursematerials` (`MaterialID`, `CourseID`, `Title`, `Type`) VALUES
(1, 101, 'Discrite mathemetics', 'Textbook,lecturesheet'),
(2, 102, 'Introduction to Computer Science', 'Lecture Notes'),
(3, 209, 'Database Management Systems', 'Slides,book');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `CourseID` int(11) NOT NULL,
  `CourseName` varchar(255) DEFAULT NULL,
  `DepartmentID` int(11) DEFAULT NULL,
  `Credits` int(11) DEFAULT NULL,
  `TotalSeats` int(11) DEFAULT NULL,
  `SeatsAvailable` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`CourseID`, `CourseName`, `DepartmentID`, `Credits`, `TotalSeats`, `SeatsAvailable`) VALUES
(101, 'Discrete Mathematics', 1, 3, 40, 25),
(102, 'Introduction to Computing', 1, 2, 30, 30),
(105, 'Algorithms', 1, 3, 40, 40),
(209, 'Database Systems', 1, 3, 40, 39),
(211, 'Computer Networks', 1, 3, 42, 42),
(306, 'Operating Systems', 1, 4, 45, 45),
(308, 'Artificial Intelligence', 1, 3, 40, 40);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DepartmentID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Head` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DepartmentID`, `Name`, `Head`) VALUES
(1, 'Computer Science and Engineering', 'DR. MUHAMMAD AMINUR ');

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `EnrollmentID` int(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `CourseID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`EnrollmentID`, `StudentID`, `CourseID`) VALUES
(2, 213002002, 209),
(4, 213002001, 101),
(5, 210002002, 101),
(8, 210002003, 101),
(9, 210002004, 101),
(11, 210002006, 101),
(12, 210002007, 101),
(13, 210002008, 101),
(14, 210002009, 101),
(16, 210002011, 101),
(17, 210002012, 101),
(18, 210002013, 101),
(20, 210002015, 101),
(21, 210002016, 101),
(22, 210002017, 101),
(23, 210002018, 101);

--
-- Triggers `enrollments`
--
DELIMITER $$
CREATE TRIGGER `trg_after_drop` AFTER DELETE ON `enrollments` FOR EACH ROW BEGIN
   UPDATE Courses
   SET SeatsAvailable = SeatsAvailable + 1
   WHERE CourseID = OLD.CourseID;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_after_enroll` AFTER INSERT ON `enrollments` FOR EACH ROW BEGIN
   UPDATE Courses
   SET SeatsAvailable = SeatsAvailable - 1
   WHERE CourseID = NEW.CourseID AND SeatsAvailable > 0;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `EventID` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `ExamID` int(11) NOT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `RoomID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`ExamID`, `CourseID`, `Date`, `RoomID`) VALUES
(1, 101, '2024-01-17', 112),
(2, 101, '2024-01-17', 113),
(3, 102, '2024-01-19', 115),
(4, 105, '2024-01-20', 116),
(5, 105, '2024-01-25', 117);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `FacultyID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Designation` varchar(20) DEFAULT NULL,
  `DepartmentID` int(11) DEFAULT NULL,
  `Office` varchar(50) DEFAULT NULL,
  `salary` double(14,5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`FacultyID`, `Name`, `Email`, `Designation`, `DepartmentID`, `Office`, `salary`) VALUES
(1, 'PROF. DR. MD. SAIFUL AZAD', 'dean@cse.green.edu.bd', 'Professor', 1, 'A-302', 150000.00000),
(2, 'DR. MUHAMMAD AMINUR RAHAMAN', 'aminur@cse.green.edu.bd', 'Associate Professor', 1, 'F-106', 140000.00000),
(3, 'MR. SYED AHSANUL KABIR', 'kabir@cse.green.edu.bd', 'Associate Professor', 1, 'F-102', 120000.00000),
(4, 'DR. MD. MOSTAFIJUR RAHMAN', 'mostafijur@cse.green.edu.bd', 'Associate Professor', 1, 'F-103', 115000.00000),
(5, 'DR. MUHAMMAD ABUL HASAN', 'muhammad.hasan@cse.green.edu.bd', 'Associate Professor', 1, 'F-102', 120000.00000),
(6, 'MS. UMME RUMAN', 'ruman@cse.green.edu.bd', 'Assistant Professor', 1, 'F-105', 110000.00000),
(7, 'MR. TAMIM AL MAHMUD', 'tamim@cse.green.edu.bd', 'Assistant Professor', 1, 'F-105', 95000.00000),
(8, 'MS. SHAMIMA AKTER', 'shamima_akter@cse.green.edu.bd', 'Assistant Professor', 1, 'F-105', 90000.00000),
(9, 'MD. SOLAIMAN MIA', 'solaiman@cse.green.edu.bd', 'Assistant Professor', 1, 'F-105', 100000.00000),
(10, 'MS. SUMAIYA KABIR', 'sumaiya@cse.green.edu.bd', 'Assistant Professor', 1, 'F-105', 89000.00000),
(11, 'DR. FAIZ AL FAISAL', 'faisal@cse.green.edu.bd', 'Assistant Professor', 1, 'F-105', 110000.00000),
(12, 'MS. SHAMIMA ISLAM', 'shamima@cse.green.edu.bd', 'Assistant Professor', 1, 'F-105', 85000.00000),
(13, 'MR. MD. JAHIDUL ISLAM', 'jahid@cse.green.edu.bd', 'Assistant Professor', 1, 'F-105', 98000.00000),
(14, 'MS. JAKIA SULTANA', 'jakia@cse.green.edu.bd', 'Assistant Professor', 1, 'F-105', 85000.00000),
(15, 'MS. FARHANA AKTER SUNNY', 'farhana@cse.green.edu.bd', 'Assistant Professor', 1, 'F-105', 87000.00000),
(16, 'MS. SHARMIN ALAM', 'sharmin@cse.green.edu.bd', 'Senior Lecturer', 1, 'A-502', 82000.00000),
(17, 'MR. HUMAYAN KABIR RANA', 'humayan@cse.green.edu.bd', 'Senior Lecturer', 1, 'A-502', 85000.00000),
(18, 'MR. MD. MONIRUL ISLAM', 'monirul@cse.green.edu.bd', 'Lecturer', 1, 'A-502', 72000.00000),
(19, 'MR. JARGIS AHMED', 'jargisn@cse.green.edu.bd', 'Lecturer', 1, 'A-502', 78000.00000),
(20, 'MS. SAMIHA ISLAM TANNI', 'samiha@cse.green.edu.bd', 'Lecturer', 1, 'A-502', 75000.00000),
(21, 'MS. BABE SULTANA', 'babe@cse.green.edu.bd', 'Lecturer', 1, 'A-502', 81000.00000);

-- --------------------------------------------------------

--
-- Stand-in structure for view `facultyview`
-- (See below for the actual view)
--
CREATE TABLE `facultyview` (
`FacultyID` int(11)
,`Name` varchar(255)
,`Email` varchar(255)
,`Designation` varchar(20)
,`DepartmentID` int(11)
,`Office` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `internshipsandplacements`
--

CREATE TABLE `internshipsandplacements` (
  `PlacementID` int(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `CompanyName` varchar(255) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `Position` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `internshipsandplacements`
--

INSERT INTO `internshipsandplacements` (`PlacementID`, `StudentID`, `CompanyName`, `StartDate`, `EndDate`, `Position`) VALUES
(1, 231002001, 'Tech Solutions Ltd.', '2023-05-01', '2023-08-31', 'Software Developer Intern'),
(2, 231002002, 'IT Innovations Inc.', '2023-06-15', '2023-09-15', 'Network Engineer Intern'),
(3, 231002003, 'Software Systems Ltd.', '2023-05-10', '2023-08-10', 'Web Developer Intern'),
(4, 231002005, 'Cybersecurity Solutions', '2023-07-01', '2023-10-01', 'Cybersecurity Analyst Intern'),
(5, 231002007, 'Data Analytics Corp.', '2023-06-01', '2023-09-30', 'Data Analyst Intern'),
(6, 231002009, 'Tech Innovators', '2023-05-20', '2023-08-20', 'Software Engineer Intern'),
(7, 231002011, 'Digital Services Ltd.', '2023-06-10', '2023-09-10', 'IT Support Intern'),
(8, 231002013, 'Cloud Computing Solutions', '2023-05-15', '2023-08-15', 'Cloud Engineer Intern'),
(9, 231002015, 'Web Design Studio', '2023-07-05', '2023-10-05', 'Web Designer Intern'),
(10, 231002017, 'Mobile App Creations', '2023-05-25', '2023-08-25', 'Mobile App Developer Intern');

-- --------------------------------------------------------

--
-- Table structure for table `labequipment`
--

CREATE TABLE `labequipment` (
  `EquipmentID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `DepartmentID` int(11) DEFAULT NULL,
  `PurchaseDate` date DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `labequipment`
--

INSERT INTO `labequipment` (`EquipmentID`, `Name`, `DepartmentID`, `PurchaseDate`, `Status`) VALUES
(1, 'Computer', 1, '2024-01-07', 'active'),
(2, 'Microprocessor', 1, '2024-01-07', 'packed'),
(3, 'Software', 1, '2024-01-07', 'active'),
(4, 'Screen', 1, '2024-01-07', 'active'),
(5, 'Monitor', 1, '2024-01-07', 'active'),
(6, 'Keyboard', 1, '2024-01-07', 'damaged'),
(7, 'Mouse', 1, '2024-01-07', 'active'),
(8, 'Printer', 1, '2024-01-07', 'active'),
(9, 'Scanner', 1, '2024-01-07', 'active'),
(10, 'Projector', 1, '2024-01-07', 'packed');

-- --------------------------------------------------------

--
-- Table structure for table `libraryresources`
--

CREATE TABLE `libraryresources` (
  `ResourceID` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Author` varchar(255) DEFAULT NULL,
  `PublicationYear` int(11) DEFAULT NULL,
  `ResourceType` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `libraryresources`
--

INSERT INTO `libraryresources` (`ResourceID`, `Title`, `Author`, `PublicationYear`, `ResourceType`) VALUES
(1, 'Introduction to Environmental Science', 'John Doe', 2020, 'Book'),
(2, 'Bangladeshs Economic Development', 'Ayesha Rahman', 2019, 'Book'),
(3, 'Green Energy and Sustainability', 'David Smith', 2021, 'Journal'),
(4, 'History of Bangladesh', 'Sarah Ahmed', 2018, 'Book'),
(5, 'Biodiversity in Bangladesh', 'Michael Brown', 2022, 'Article'),
(6, 'Renewable Energy Technologies', 'Laura Wilson', 2017, 'Book'),
(7, 'Climate Change Adaptation', 'Daniel Clark', 2016, 'Journal'),
(8, 'Environmental Ethics', 'Sophia Turner', 2017, 'Book'),
(9, 'Sustainable Agriculture Practices', 'Alex Martin', 2019, 'Article'),
(10, 'Waste Management in Bangladesh', 'Olivia Davis', 2019, 'Book');

-- --------------------------------------------------------

--
-- Table structure for table `markslab`
--

CREATE TABLE `markslab` (
  `sl_no` int(11) NOT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `CourseName` varchar(20) DEFAULT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `Name` varchar(222) DEFAULT NULL,
  `CLP` int(11) DEFAULT NULL,
  `LAB_REPORT` int(11) DEFAULT NULL,
  `PROJECT_FINAL` int(11) DEFAULT NULL,
  `LAB_FINAL` int(11) DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `Grade` char(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `markslab`
--

INSERT INTO `markslab` (`sl_no`, `CourseID`, `CourseName`, `StudentID`, `Name`, `CLP`, `LAB_REPORT`, `PROJECT_FINAL`, `LAB_FINAL`, `Total`, `Grade`) VALUES
(1, 105, 'ALGORITHM', 213002001, 'Hridoy Debnath', 22, 12, 24, 21, 79, 'A');

--
-- Triggers `markslab`
--
DELIMITER $$
CREATE TRIGGER `LAB_MARK_UPDATE` BEFORE INSERT ON `markslab` FOR EACH ROW BEGIN
SET NEW.TOTAL = NEW.CLP + NEW.LAB_REPORT + NEW.PROJECT_FINAL + NEW.LAB_FINAL ; 
 
   IF NEW.TOTAL >=80 AND NEW.TOTAL<100 THEN SET NEW.GRADE = 'A+';
ELSEIF NEW.TOTAL>=75 AND NEW.TOTAL<80 THEN SET NEW.GRADE = 'A';
ELSEIF NEW.TOTAL>=70 AND NEW.TOTAL<75 THEN SET NEW.GRADE = 'A-';
ELSEIF NEW.TOTAL>=65 AND NEW.TOTAL<70 THEN SET NEW.GRADE = 'B+';
ELSEIF NEW.TOTAL>=60 AND NEW.TOTAL<65 THEN SET NEW.GRADE = 'B';
ELSEIF NEW.TOTAL>=55 AND NEW.TOTAL<60 THEN SET NEW.GRADE = 'B-';
ELSEIF NEW.TOTAL>=50 AND NEW.TOTAL<55 THEN SET NEW.GRADE = 'C+';
ELSEIF NEW.TOTAL>=45 AND NEW.TOTAL<50 THEN SET NEW.GRADE = 'C';
ELSEIF NEW.TOTAL>=40 AND NEW.TOTAL<45 THEN SET NEW.GRADE = 'D';

ELSE SET NEW.GRADE = 'F'; 
END IF; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `markstheory`
--

CREATE TABLE `markstheory` (
  `sl_no` int(11) NOT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `CourseName` varchar(20) DEFAULT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `Name` varchar(222) DEFAULT NULL,
  `KSA1` int(11) DEFAULT NULL,
  `KSA2` int(11) DEFAULT NULL,
  `CT` int(11) DEFAULT NULL,
  `MID` int(11) DEFAULT NULL,
  `FINAL` int(11) DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `Grade` char(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `markstheory`
--

INSERT INTO `markstheory` (`sl_no`, `CourseID`, `CourseName`, `StudentID`, `Name`, `KSA1`, `KSA2`, `CT`, `MID`, `FINAL`, `Total`, `Grade`) VALUES
(1, 101, 'Discrite Mathemetics', 213002001, 'Hridoy Debnath', 8, 9, 8, 26, 34, 85, 'A+'),
(2, 101, 'Discrite Mathemetics', 213002002, 'Mohammad ali', 2, 6, 4, 16, 24, 52, 'C+');

--
-- Triggers `markstheory`
--
DELIMITER $$
CREATE TRIGGER `theorymarkupdate` BEFORE INSERT ON `markstheory` FOR EACH ROW BEGIN
SET NEW.TOTAL = NEW.KSA1 + NEW.KSA2 + NEW.CT + NEW.MID + NEW.FINAL; 
 
   IF NEW.TOTAL >=80 AND NEW.TOTAL<100 THEN SET NEW.GRADE = 'A+';
ELSEIF NEW.TOTAL>=75 AND NEW.TOTAL<80 THEN SET NEW.GRADE = 'A';
ELSEIF NEW.TOTAL>=70 AND NEW.TOTAL<75 THEN SET NEW.GRADE = 'A-';
ELSEIF NEW.TOTAL>=65 AND NEW.TOTAL<70 THEN SET NEW.GRADE = 'B+';
ELSEIF NEW.TOTAL>=60 AND NEW.TOTAL<65 THEN SET NEW.GRADE = 'B';
ELSEIF NEW.TOTAL>=55 AND NEW.TOTAL<60 THEN SET NEW.GRADE = 'B-';
ELSEIF NEW.TOTAL>=50 AND NEW.TOTAL<55 THEN SET NEW.GRADE = 'C+';
ELSEIF NEW.TOTAL>=45 AND NEW.TOTAL<50 THEN SET NEW.GRADE = 'C';
ELSEIF NEW.TOTAL>=40 AND NEW.TOTAL<45 THEN SET NEW.GRADE = 'D';

ELSE SET NEW.GRADE = 'F'; 
END IF; 
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `researchprojects`
--

CREATE TABLE `researchprojects` (
  `ProjectID` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `LeadFacultyID` int(11) DEFAULT NULL,
  `Budget` decimal(10,2) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `researchprojects`
--

INSERT INTO `researchprojects` (`ProjectID`, `Title`, `LeadFacultyID`, `Budget`, `StartDate`, `EndDate`) VALUES
(1, 'An Energy Efficient Model of Software Development Life Cycle for Mobile Application', 9, 110000.00, '2022-02-01', '0000-00-00'),
(2, 'Real-Time Recognition of Bangla Sign Language using Convolutional Neural Network', 2, 100000.50, '2022-03-15', '2022-12-31');

-- --------------------------------------------------------

--
-- Table structure for table `studentattendance`
--

CREATE TABLE `studentattendance` (
  `StudentID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Status` enum('absent','present') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studentattendance`
--

INSERT INTO `studentattendance` (`StudentID`, `CourseID`, `Date`, `Status`) VALUES
(213002001, 101, '2023-01-10', 'absent'),
(213002002, 101, '2023-01-10', 'present');

-- --------------------------------------------------------

--
-- Table structure for table `studentresult`
--

CREATE TABLE `studentresult` (
  `RegNo` int(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `CGPA` decimal(3,2) NOT NULL,
  `Dept` varchar(50) DEFAULT NULL,
  `Semester` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studentresult`
--

INSERT INTO `studentresult` (`RegNo`, `StudentID`, `CGPA`, `Dept`, `Semester`) VALUES
(1, 213002001, 3.50, 'CSE', 'Fall 2023'),
(2, 213002002, 3.60, 'CSE', 'Fall 2023'),
(3, 213002003, 3.70, 'CSE', 'Fall 2023'),
(4, 213002004, 3.80, 'CSE', 'Fall 2023'),
(5, 213002005, 3.90, 'CSE', 'Fall 2023'),
(6, 213002006, 3.40, 'CSE', 'Fall 2023'),
(7, 213002007, 3.30, 'CSE', 'Fall 2023'),
(8, 213002008, 3.20, 'CSE', 'Fall 2023'),
(9, 213002009, 3.10, 'CSE', 'Fall 2023'),
(10, 213002010, 3.00, 'CSE', 'Fall 2023');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `StudentID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Program` varchar(255) DEFAULT NULL,
  `Batch` varchar(255) DEFAULT NULL,
  `Probation` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`StudentID`, `Name`, `Email`, `Program`, `Batch`, `Probation`) VALUES
(213002001, 'Hridoy Debnath', 'hridoydebnath@gmail.com', 'CSE(REGULAR)', '213', 0),
(213002002, 'Mohammad Ali', 'mohammad.ali213@gmail.com', 'CSE(EVENING)', '213', 0),
(213002003, 'Farhana Akter', 'farhana.akter213@gmail.com', 'CSE(REGULAR)', '213', 0),
(213002004, 'Rahim Uddin', 'rahim.uddin213@gmail.com', 'CSE(EVENING)', '213', 1),
(213002005, 'Sadia Islam', 'sadia.islam213@gmail.com', 'CSE(REGULAR)', '213', 0),
(213002006, 'Kamal Hussain', 'kamal.hussain213@gmail.com', 'CSE(EVENING)', '213', 0),
(213002007, 'Nadia Chowdhury', 'nadia.chowdhury213@gmail.com', 'CSE(REGULAR)', '213', 0),
(213002008, 'Faisal Ahmed', 'faisal.ahmed213@gmail.com', 'CSE(EVENING)', '213', 1),
(213002009, 'Tasnim Haque', 'tasnim.haque213@gmail.com', 'CSE(REGULAR)', '213', 0),
(213002010, 'Asif Rahman', 'asif.rahman213@gmail.com', 'CSE(EVENING)', '213', 0),
(213002011, 'Laila Begum', 'laila.begum213@gmail.com', 'CSE(REGULAR)', '213', 0),
(213002012, 'Zahid Hasan', 'zahid.hasan213@gmail.com', 'CSE(EVENING)', '213', 1),
(213002013, 'Mehedi Hassan', 'mehedi.hassan213@gmail.com', 'CSE(REGULAR)', '213', 0),
(213002014, 'Sultana Razia', 'sultana.razia213@gmail.com', 'CSE(EVENING)', '213', 0),
(213002015, 'Anwar Hossain', 'anwar.hossain213@gmail.com', 'CSE(REGULAR)', '213', 0),
(213002016, 'Sharmin Akhter', 'sharmin.akhter213@gmail.com', 'CSE(EVENING)', '213', 1),
(213002017, 'Bilal Khan', 'bilal.khan213@gmail.com', 'CSE(REGULAR)', '213', 0),
(213002018, 'Rokhsana Khatun', 'rokhsana.khatun213@gmail.com', 'CSE(EVENING)', '213', 0),
(213002019, 'Tariqul Islam', 'tariqul.islam213@gmail.com', 'CSE(REGULAR)', '213', 1),
(213002020, 'Sumaiya Siddiqui', 'sumaiya.siddiqui213@gmail.com', 'CSE(EVENING)', '213', 0),
(221002001, 'Irfan Chowdhury', 'irfan.chowdhury221@gmail.com', 'CSE(REGULAR)', '221', 0),
(221002002, 'Nusrat Jahan', 'nusrat.jahan221@gmail.com', 'CSE(EVENING)', '221', 0),
(221002003, 'Tahmid Rahman', 'tahmid.rahman221@gmail.com', 'CSE(REGULAR)', '221', 0),
(221002004, 'Munira Khatun', 'munira.khatun221@gmail.com', 'CSE(EVENING)', '221', 1),
(221002005, 'Sohel Rana', 'sohel.rana221@gmail.com', 'CSE(REGULAR)', '221', 0),
(221002006, 'Fariha Mahmud', 'fariha.mahmud221@gmail.com', 'CSE(EVENING)', '221', 0),
(221002007, 'Rafiqul Islam', 'rafiqul.islam221@gmail.com', 'CSE(REGULAR)', '221', 0),
(221002008, 'Sabina Yasmin', 'sabina.yasmin221@gmail.com', 'CSE(EVENING)', '221', 1),
(221002009, 'Hasan Mahmood', 'hasan.mahmood221@gmail.com', 'CSE(REGULAR)', '221', 0),
(221002010, 'Shamima Begum', 'shamima.begum221@gmail.com', 'CSE(EVENING)', '221', 0),
(221002011, 'Arif Hossain', 'arif.hossain221@gmail.com', 'CSE(REGULAR)', '221', 0),
(221002012, 'Ruma Akter', 'ruma.akter221@gmail.com', 'CSE(EVENING)', '221', 1),
(221002013, 'Fahad Bin Zaman', 'fahad.zaman221@gmail.com', 'CSE(REGULAR)', '221', 0),
(221002014, 'Lipi Akter', 'lipi.akter221@gmail.com', 'CSE(EVENING)', '221', 0),
(221002015, 'Sajid Khan', 'sajid.khan221@gmail.com', 'CSE(REGULAR)', '221', 0),
(221002016, 'Tania Sultana', 'tania.sultana221@gmail.com', 'CSE(EVENING)', '221', 1),
(221002017, 'Rakib Hasan', 'rakib.hasan221@gmail.com', 'CSE(REGULAR)', '221', 0),
(221002018, 'Simin Rahman', 'simin.rahman221@gmail.com', 'CSE(EVENING)', '221', 0),
(221002019, 'Mahir Chowdhury', 'mahir.chowdhury221@gmail.com', 'CSE(REGULAR)', '221', 1),
(221002020, 'Naima Akter', 'naima.akter221@gmail.com', 'CSE(EVENING)', '221', 0),
(222002001, 'Jamil Ahmed', 'jamil.ahmed222@gmail.com', 'CSE(REGULAR)', '222', 0),
(222002002, 'Rehana Begum', 'rehana.begum222@gmail.com', 'CSE(EVENING)', '222', 0),
(222002003, 'Tanvir Hasan', 'tanvir.hasan222@gmail.com', 'CSE(REGULAR)', '222', 0),
(222002004, 'Rasheda Khatun', 'rasheda.khatun222@gmail.com', 'CSE(EVENING)', '222', 1),
(222002005, 'Shakil Khan', 'shakil.khan222@gmail.com', 'CSE(REGULAR)', '222', 0),
(222002006, 'Lubna Chowdhury', 'lubna.chowdhury222@gmail.com', 'CSE(EVENING)', '222', 0),
(222002007, 'Samiul Islam', 'samiul.islam222@gmail.com', 'CSE(REGULAR)', '222', 0),
(222002008, 'Fahima Akter', 'fahima.akter222@gmail.com', 'CSE(EVENING)', '222', 1),
(222002009, 'Khalid Mahmud', 'khalid.mahmud222@gmail.com', 'CSE(REGULAR)', '222', 0),
(222002010, 'Tasfia Mirza', 'tasfia.mirza222@gmail.com', 'CSE(EVENING)', '222', 0),
(222002011, 'Sajjad Hossain', 'sajjad.hossain222@gmail.com', 'CSE(REGULAR)', '222', 0),
(222002012, 'Mariam Sultan', 'mariam.sultan222@gmail.com', 'CSE(EVENING)', '222', 1),
(222002013, 'Anisur Rahman', 'anisur.rahman222@gmail.com', 'CSE(REGULAR)', '222', 0),
(222002014, 'Sumona Haque', 'sumona.haque222@gmail.com', 'CSE(EVENING)', '222', 0),
(222002015, 'Imran Chowdhury', 'imran.chowdhury222@gmail.com', 'CSE(REGULAR)', '222', 0),
(222002016, 'Farzana Alam', 'farzana.alam222@gmail.com', 'CSE(EVENING)', '222', 1),
(222002017, 'Rafsan Jani', 'rafsan.jani222@gmail.com', 'CSE(REGULAR)', '222', 0),
(222002018, 'Sadia Afrin', 'sadia.afrin222@gmail.com', 'CSE(EVENING)', '222', 0),
(222002019, 'Al Amin', 'al.amin222@gmail.com', 'CSE(REGULAR)', '222', 1),
(222002020, 'Tania Rahman', 'tania.rahman222@gmail.com', 'CSE(EVENING)', '222', 0),
(231002001, 'Asif Iqbal', 'asif.iqbal231@gmail.com', 'CSE(REGULAR)', '231', 0),
(231002002, 'Nahid Parvez', 'nahid.parvez231@gmail.com', 'CSE(EVENING)', '231', 0),
(231002003, 'Sharmin Akhtar', 'sharmin.akhtar231@gmail.com', 'CSE(REGULAR)', '231', 0),
(231002004, 'Abul Kashem', 'abul.kashem231@gmail.com', 'CSE(EVENING)', '231', 1),
(231002005, 'Rifat Ara', 'rifat.ara231@gmail.com', 'CSE(REGULAR)', '231', 0),
(231002006, 'Munir Hasan', 'munir.hasan231@gmail.com', 'CSE(EVENING)', '231', 0),
(231002007, 'Tamanna Rahman', 'tamanna.rahman231@gmail.com', 'CSE(REGULAR)', '231', 0),
(231002008, 'Sohail Mahmud', 'sohail.mahmud231@gmail.com', 'CSE(EVENING)', '231', 1),
(231002009, 'Humaira Begum', 'humaira.begum231@gmail.com', 'CSE(REGULAR)', '231', 0),
(231002010, 'Rakibul Islam', 'rakibul.islam231@gmail.com', 'CSE(EVENING)', '231', 0),
(231002011, 'Fahmida Haque', 'fahmida.haque231@gmail.com', 'CSE(REGULAR)', '231', 0),
(231002012, 'Mehrab Hossain', 'mehrab.hossain231@gmail.com', 'CSE(EVENING)', '231', 1),
(231002013, 'Sadia Sultana', 'sadia.sultana231@gmail.com', 'CSE(REGULAR)', '231', 0),
(231002014, 'Imtiaz Ahmed', 'imtiaz.ahmed231@gmail.com', 'CSE(EVENING)', '231', 0),
(231002015, 'Lamia Tasnim', 'lamia.tasnim231@gmail.com', 'CSE(REGULAR)', '231', 0),
(231002016, 'Touhidur Rahman', 'touhidur.rahman231@gmail.com', 'CSE(EVENING)', '231', 1),
(231002017, 'Farhana Chowdhury', 'farhana.chowdhury231@gmail.com', 'CSE(REGULAR)', '231', 0),
(231002018, 'Shahed Karim', 'shahed.karim231@gmail.com', 'CSE(EVENING)', '231', 0),
(231002019, 'Marufa Akter', 'marufa.akter231@gmail.com', 'CSE(REGULAR)', '231', 1),
(231002020, 'Ashraful Alam', 'ashraful.alam231@gmail.com', 'CSE(EVENING)', '231', 0),
(232002001, 'Nazia Rahman', 'nazia.rahman232@gmail.com', 'CSE(REGULAR)', '232', 0),
(232002002, 'Sakib Ahmed', 'sakib.ahmed232@gmail.com', 'CSE(EVENING)', '232', 0),
(232002003, 'Tasnim Jahan', 'tasnim.jahan232@gmail.com', 'CSE(REGULAR)', '232', 0),
(232002004, 'Imran Khan', 'imran.khan232@gmail.com', 'CSE(EVENING)', '232', 1),
(232002005, 'Rafiul Islam', 'rafiul.islam232@gmail.com', 'CSE(REGULAR)', '232', 0),
(232002006, 'Farzana Akter', 'farzana.akter232@gmail.com', 'CSE(EVENING)', '232', 0),
(232002007, 'Saifur Rahman', 'saifur.rahman232@gmail.com', 'CSE(REGULAR)', '232', 0),
(232002008, 'Moinul Islam', 'moinul.islam232@gmail.com', 'CSE(EVENING)', '232', 1),
(232002009, 'Tahmina Sultana', 'tahmina.sultana232@gmail.com', 'CSE(REGULAR)', '232', 0),
(232002010, 'Jubayer Ahmed', 'jubayer.ahmed232@gmail.com', 'CSE(EVENING)', '232', 0),
(232002011, 'Afroza Akter', 'afroza.akter232@gmail.com', 'CSE(REGULAR)', '232', 0),
(232002012, 'Mizanur Rahman', 'mizanur.rahman232@gmail.com', 'CSE(EVENING)', '232', 1),
(232002013, 'Sara Khan', 'sara.khan232@gmail.com', 'CSE(REGULAR)', '232', 0),
(232002014, 'Jamal Uddin', 'jamal.uddin232@gmail.com', 'CSE(EVENING)', '232', 0),
(232002015, 'Rahima Begum', 'rahima.begum232@gmail.com', 'CSE(REGULAR)', '232', 0),
(232002016, 'Tasnim Rahman', 'tasnim.rahman232@gmail.com', 'CSE(EVENING)', '232', 1),
(232002017, 'Raisa Chowdhury', 'raisa.chowdhury232@gmail.com', 'CSE(REGULAR)', '232', 0),
(232002018, 'Sohel Ahmed', 'sohel.ahmed232@gmail.com', 'CSE(EVENING)', '232', 0),
(232002019, 'Rukhsar Akter', 'rukhsar.akter232@gmail.com', 'CSE(REGULAR)', '232', 1),
(232002020, 'Sabbir Hossain', 'sabbir.hossain232@gmail.com', 'CSE(EVENING)', '232', 0),
(241002001, 'Rahim Ali', 'rahim.ali241@gmail.com', 'CSE(REGULAR)', '241', 0),
(241002002, 'Amina Rahman', 'amina.rahman241@gmail.com', 'CSE(EVENING)', '241', 0),
(241002003, 'Faisal Ahmed', 'faisal.ahmed241@gmail.com', 'CSE(REGULAR)', '241', 0),
(241002004, 'Nusrat Jahan', 'nusrat.jahan241@gmail.com', 'CSE(EVENING)', '241', 1),
(241002005, 'Samiul Islam', 'samiul.islam241@gmail.com', 'CSE(REGULAR)', '241', 0),
(241002006, 'Tasnim Ahmed', 'tasnim.ahmed241@gmail.com', 'CSE(EVENING)', '241', 0),
(241002007, 'Ayesha Khan', 'ayesha.khan241@gmail.com', 'CSE(REGULAR)', '241', 0),
(241002008, 'Rahat Islam', 'rahat.islam241@gmail.com', 'CSE(EVENING)', '241', 1),
(241002009, 'Samira Akter', 'samira.akter241@gmail.com', 'CSE(REGULAR)', '241', 0),
(241002010, 'Kamrul Hasan', 'kamrul.hasan241@gmail.com', 'CSE(EVENING)', '241', 0),
(241002011, 'Sadia Rahman', 'sadia.rahman241@gmail.com', 'CSE(REGULAR)', '241', 0),
(241002012, 'Ismail Khan', 'ismail.khan241@gmail.com', 'CSE(EVENING)', '241', 1),
(241002013, 'Anika Islam', 'anika.islam241@gmail.com', 'CSE(REGULAR)', '241', 0),
(241002014, 'Mithun Ahmed', 'mithun.ahmed241@gmail.com', 'CSE(EVENING)', '241', 0),
(241002015, 'Nashra Begum', 'nashra.begum241@gmail.com', 'CSE(REGULAR)', '241', 0),
(241002016, 'Afnan Rahman', 'afnan.rahman241@gmail.com', 'CSE(EVENING)', '241', 1),
(241002017, 'Sumaiya Chowdhury', 'sumaiya.chowdhury241@gmail.com', 'CSE(REGULAR)', '241', 0),
(241002018, 'Shahid Ahmed', 'shahid.ahmed241@gmail.com', 'CSE(EVENING)', '241', 0),
(241002019, 'Nadia Akter', 'nadia.akter241@gmail.com', 'CSE(REGULAR)', '241', 1),
(241002020, 'Rifat Hossain', 'rifat.hossain241@gmail.com', 'CSE(EVENING)', '241', 0);

-- --------------------------------------------------------

--
-- Table structure for table `teacherattendance`
--

CREATE TABLE `teacherattendance` (
  `TeacherID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Status` enum('present','absent') DEFAULT NULL,
  `EnterTime` time DEFAULT NULL,
  `LeaveTime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacherattendance`
--

INSERT INTO `teacherattendance` (`TeacherID`, `Date`, `Status`, `EnterTime`, `LeaveTime`) VALUES
(1, '2024-01-10', 'present', '08:00:00', '16:00:00'),
(2, '2024-01-10', 'present', '09:00:00', '15:30:00'),
(3, '2024-01-10', 'absent', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE `timetable` (
  `TimetableID` int(11) NOT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `facultyID` int(11) DEFAULT NULL,
  `RoomID` int(11) DEFAULT NULL,
  `DayOfWeek` varchar(15) DEFAULT NULL,
  `StartTime` time DEFAULT NULL,
  `EndTime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure for view `facultyview`
--
DROP TABLE IF EXISTS `facultyview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `facultyview`  AS SELECT `faculty`.`FacultyID` AS `FacultyID`, `faculty`.`Name` AS `Name`, `faculty`.`Email` AS `Email`, `faculty`.`Designation` AS `Designation`, `faculty`.`DepartmentID` AS `DepartmentID`, `faculty`.`Office` AS `Office` FROM `faculty` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrativestaff`
--
ALTER TABLE `administrativestaff`
  ADD PRIMARY KEY (`StaffID`),
  ADD UNIQUE KEY `StaffID` (`StaffID`),
  ADD KEY `DepartmentID` (`DepartmentID`);

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`AlumniID`),
  ADD UNIQUE KEY `AlumniID` (`AlumniID`);

--
-- Indexes for table `billhistory`
--
ALTER TABLE `billhistory`
  ADD PRIMARY KEY (`BillSerial`),
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`RoomID`),
  ADD UNIQUE KEY `RoomID` (`RoomID`);

--
-- Indexes for table `clubs`
--
ALTER TABLE `clubs`
  ADD PRIMARY KEY (`ClubID`),
  ADD UNIQUE KEY `UC_ClubID` (`ClubID`);

--
-- Indexes for table `courseevaluations`
--
ALTER TABLE `courseevaluations`
  ADD PRIMARY KEY (`EvaluationID`),
  ADD UNIQUE KEY `UC_EvaluationID` (`EvaluationID`),
  ADD KEY `CourseID` (`CourseID`),
  ADD KEY `StudentID` (`StudentID`),
  ADD KEY `FacultyID` (`FacultyID`);

--
-- Indexes for table `coursematerials`
--
ALTER TABLE `coursematerials`
  ADD PRIMARY KEY (`MaterialID`),
  ADD UNIQUE KEY `MaterialID` (`MaterialID`),
  ADD KEY `CourseID` (`CourseID`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`CourseID`),
  ADD KEY `DepartmentID` (`DepartmentID`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`DepartmentID`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`EnrollmentID`),
  ADD KEY `CourseID` (`CourseID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`EventID`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`ExamID`),
  ADD UNIQUE KEY `ExamID` (`ExamID`),
  ADD KEY `CourseID` (`CourseID`),
  ADD KEY `RoomID` (`RoomID`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`FacultyID`),
  ADD UNIQUE KEY `FacultyID` (`FacultyID`),
  ADD KEY `DepartmentID` (`DepartmentID`);

--
-- Indexes for table `internshipsandplacements`
--
ALTER TABLE `internshipsandplacements`
  ADD PRIMARY KEY (`PlacementID`),
  ADD UNIQUE KEY `PlacementID` (`PlacementID`),
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `labequipment`
--
ALTER TABLE `labequipment`
  ADD PRIMARY KEY (`EquipmentID`),
  ADD UNIQUE KEY `EquipmentID` (`EquipmentID`),
  ADD KEY `DepartmentID` (`DepartmentID`);

--
-- Indexes for table `libraryresources`
--
ALTER TABLE `libraryresources`
  ADD PRIMARY KEY (`ResourceID`),
  ADD UNIQUE KEY `ResourceID` (`ResourceID`);

--
-- Indexes for table `markslab`
--
ALTER TABLE `markslab`
  ADD PRIMARY KEY (`sl_no`);

--
-- Indexes for table `markstheory`
--
ALTER TABLE `markstheory`
  ADD PRIMARY KEY (`sl_no`),
  ADD KEY `FK_CourseID` (`CourseID`),
  ADD KEY `FK_StudentID` (`StudentID`);

--
-- Indexes for table `researchprojects`
--
ALTER TABLE `researchprojects`
  ADD PRIMARY KEY (`ProjectID`),
  ADD UNIQUE KEY `ProjectID` (`ProjectID`),
  ADD KEY `LeadFacultyID` (`LeadFacultyID`);

--
-- Indexes for table `studentattendance`
--
ALTER TABLE `studentattendance`
  ADD PRIMARY KEY (`StudentID`,`CourseID`,`Date`),
  ADD KEY `CourseID` (`CourseID`);

--
-- Indexes for table `studentresult`
--
ALTER TABLE `studentresult`
  ADD PRIMARY KEY (`RegNo`),
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`StudentID`);

--
-- Indexes for table `teacherattendance`
--
ALTER TABLE `teacherattendance`
  ADD PRIMARY KEY (`TeacherID`,`Date`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`TimetableID`),
  ADD UNIQUE KEY `TimetableID` (`TimetableID`),
  ADD KEY `CourseID` (`CourseID`),
  ADD KEY `facultyID` (`facultyID`),
  ADD KEY `RoomID` (`RoomID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billhistory`
--
ALTER TABLE `billhistory`
  MODIFY `BillSerial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `CourseID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=408;

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `EnrollmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `markslab`
--
ALTER TABLE `markslab`
  MODIFY `sl_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `markstheory`
--
ALTER TABLE `markstheory`
  MODIFY `sl_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `studentresult`
--
ALTER TABLE `studentresult`
  MODIFY `RegNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `administrativestaff`
--
ALTER TABLE `administrativestaff`
  ADD CONSTRAINT `administrativestaff_ibfk_1` FOREIGN KEY (`DepartmentID`) REFERENCES `departments` (`DepartmentID`);

--
-- Constraints for table `billhistory`
--
ALTER TABLE `billhistory`
  ADD CONSTRAINT `billhistory_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`);

--
-- Constraints for table `courseevaluations`
--
ALTER TABLE `courseevaluations`
  ADD CONSTRAINT `courseevaluations_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `courses` (`CourseID`),
  ADD CONSTRAINT `courseevaluations_ibfk_2` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`),
  ADD CONSTRAINT `courseevaluations_ibfk_3` FOREIGN KEY (`FacultyID`) REFERENCES `faculty` (`FacultyID`);

--
-- Constraints for table `coursematerials`
--
ALTER TABLE `coursematerials`
  ADD CONSTRAINT `coursematerials_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `courses` (`CourseID`);

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`DepartmentID`) REFERENCES `departments` (`DepartmentID`);

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `courses` (`CourseID`);

--
-- Constraints for table `exams`
--
ALTER TABLE `exams`
  ADD CONSTRAINT `exams_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `courses` (`CourseID`),
  ADD CONSTRAINT `exams_ibfk_2` FOREIGN KEY (`RoomID`) REFERENCES `classrooms` (`RoomID`);

--
-- Constraints for table `faculty`
--
ALTER TABLE `faculty`
  ADD CONSTRAINT `faculty_ibfk_1` FOREIGN KEY (`DepartmentID`) REFERENCES `departments` (`DepartmentID`);

--
-- Constraints for table `internshipsandplacements`
--
ALTER TABLE `internshipsandplacements`
  ADD CONSTRAINT `internshipsandplacements_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`);

--
-- Constraints for table `labequipment`
--
ALTER TABLE `labequipment`
  ADD CONSTRAINT `labequipment_ibfk_1` FOREIGN KEY (`DepartmentID`) REFERENCES `departments` (`DepartmentID`);

--
-- Constraints for table `markstheory`
--
ALTER TABLE `markstheory`
  ADD CONSTRAINT `FK_CourseID` FOREIGN KEY (`CourseID`) REFERENCES `courses` (`CourseID`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_StudentID` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`) ON DELETE CASCADE;

--
-- Constraints for table `researchprojects`
--
ALTER TABLE `researchprojects`
  ADD CONSTRAINT `researchprojects_ibfk_1` FOREIGN KEY (`LeadFacultyID`) REFERENCES `faculty` (`FacultyID`);

--
-- Constraints for table `studentattendance`
--
ALTER TABLE `studentattendance`
  ADD CONSTRAINT `studentattendance_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`),
  ADD CONSTRAINT `studentattendance_ibfk_2` FOREIGN KEY (`CourseID`) REFERENCES `courses` (`CourseID`);

--
-- Constraints for table `studentresult`
--
ALTER TABLE `studentresult`
  ADD CONSTRAINT `studentresult_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `students` (`StudentID`);

--
-- Constraints for table `teacherattendance`
--
ALTER TABLE `teacherattendance`
  ADD CONSTRAINT `teacherattendance_ibfk_1` FOREIGN KEY (`TeacherID`) REFERENCES `faculty` (`FacultyID`);

--
-- Constraints for table `timetable`
--
ALTER TABLE `timetable`
  ADD CONSTRAINT `timetable_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `courses` (`CourseID`),
  ADD CONSTRAINT `timetable_ibfk_2` FOREIGN KEY (`facultyID`) REFERENCES `faculty` (`FacultyID`),
  ADD CONSTRAINT `timetable_ibfk_3` FOREIGN KEY (`RoomID`) REFERENCES `classrooms` (`RoomID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
